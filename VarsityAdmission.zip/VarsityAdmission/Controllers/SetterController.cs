﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VarsityAdmission.Models;
namespace VarsityAdmission.Controllers
{
    public class SetterController : Controller
    {
        // GET: Setter
        public ActionResult Details(int id)
        {
            SetterDBContext setterDBContext = new SetterDBContext();
            Setter setter= setterDBContext.Setters.Single(set =>set.setter_id==id);
            return View(setter);
            
        }
    }
}