﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VarsityAdmission.Models;
namespace VarsityAdmission.Controllers
{
    public class QuestionController : Controller
    {
        // GET: Question
        public ActionResult Details(int id)
        {
            QuestionDBContext questionDBContext = new QuestionDBContext();
            Question question = questionDBContext.Questions.Single(ques => ques.ques_id == id);
            return View(question);
        }
    }
}