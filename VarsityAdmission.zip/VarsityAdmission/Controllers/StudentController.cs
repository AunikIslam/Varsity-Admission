﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VarsityAdmission.Models;

namespace VarsityAdmission.Controllers
{
    public class StudentController : Controller
    {
        [HttpPost]
        
        public ActionResult Details(Student newstudent)
        {
           StudentDBContext studentDBContext = new StudentDBContext();
            //Student student=studentDBContext.Students.Single(stu => stu.student_id == id);
            if (ModelState.IsValid)
            {
                studentDBContext.addStudent(newstudent);
                studentDBContext.SaveChanges();
                return RedirectToAction("Details");
            }
            else
            {
                return View(newstudent);
            }
        }
    }
}