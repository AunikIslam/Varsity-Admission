﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VarsityAdmission.Models;
namespace VarsityAdmission.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Details(int id)
        {
            LoginDBContext loginDBContext = new LoginDBContext();
            Login login = loginDBContext.Logins.Single(log => log.No == id);
            return View(login);
           
        }
    }
}