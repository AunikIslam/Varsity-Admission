﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace VarsityAdmission.Models
{
    public class LoginDBContext:DbContext
    {
        public DbSet<Login> Logins { get; set; }
    }
}