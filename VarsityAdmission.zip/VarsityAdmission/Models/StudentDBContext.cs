﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace VarsityAdmission.Models
{
    public class StudentDBContext : DbContext
    {
        public DbSet<Student> Students { get; set; }

        public void addStudent(Student student)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["StudentDBContext"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("spAddStudent", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                SqlParameter paramid = new SqlParameter();
                paramid.ParameterName = "@student_id";
                paramid.Value = student.student_id;
                cmd.Parameters.Add(paramid);

                SqlParameter paramname = new SqlParameter();
                paramname.ParameterName = "@name";
                paramname.Value = student.name;
                cmd.Parameters.Add(paramname);

                SqlParameter paramemail = new SqlParameter();
                paramemail.ParameterName = "@email";
                paramemail.Value = student.email;
                cmd.Parameters.Add(paramemail);


                SqlParameter paramphone = new SqlParameter();
                paramphone.ParameterName = "@phon_no";
                paramphone.Value = student.phon_no;
                cmd.Parameters.Add(paramphone);


                SqlParameter paramatt = new SqlParameter();
                paramatt.ParameterName = "@attendance";
                paramatt.Value = student.attendance;
                cmd.Parameters.Add(paramatt);

                SqlParameter paramobt = new SqlParameter();
                paramobt.ParameterName = "@obtained_marks";
                paramobt.Value = student.obtained_marks;
                cmd.Parameters.Add(paramobt);


                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}