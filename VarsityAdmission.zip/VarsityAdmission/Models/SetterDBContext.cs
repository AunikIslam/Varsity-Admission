﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace VarsityAdmission.Models
{
    public class SetterDBContext: DbContext
    {
         
        
            public DbSet<Setter> Setters { get; set; }
        
    }
}