﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
namespace VarsityAdmission.Models
{
    [Table("question")]
   
    public class Question
    {
        [Key]
        public int ques_id { get; set; }
        public string body { get; set; }
        public string option_one { get; set; }
        public string option_two { get; set; }
        public string option_three { get; set; }
        public string option_four { get; set; }
        public string answer { get; set; }
    }
}