﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace VarsityAdmission.Models
{
    public class QuestionDBContext:DbContext
    {
        public DbSet<Question> Questions { get; set; }
    }
}