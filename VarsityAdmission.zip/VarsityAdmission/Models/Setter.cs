﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace VarsityAdmission.Models
{
    [Table("Setter")]
    public class Setter
    {
        [Key]
        public int setter_id { get; set; }
        public string name { get; set;}
        public string email { get; set; }
    }
}