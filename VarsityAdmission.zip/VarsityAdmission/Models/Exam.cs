﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace VarsityAdmission.Models
{
    [Table("Exam")]
    public class Exam
    {
        [Key]
        public int exam_id { get; set; }
        public int year { get; set; }
        public int no_of_ques { get; set; }
        public string total_time { get; set; }
        public int pass_mark { get; set; }
     
        public int total_seat { get; set; }
    }
}