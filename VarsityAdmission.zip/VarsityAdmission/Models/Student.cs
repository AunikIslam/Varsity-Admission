﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.Entity;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace VarsityAdmission.Models
{
    [Table("Student")]
    public class Student
    {
        [Key]
        public int student_id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string phon_no { get; set; }
        public bool attendance { get; set; }
        public int obtained_marks { get; set; }
    }
    
}